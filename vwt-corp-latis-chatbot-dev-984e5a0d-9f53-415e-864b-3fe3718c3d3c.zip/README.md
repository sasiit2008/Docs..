# ChatBot

### Modules Used

##### aws-sdk is also one of the main packages used in the application ("aws-sdk": "^2.969.0")

 ##### "aws-param-store": "^3.2.0" :
 Used to fetch the account details like usernames/ keys from aws
##### File : 
vwt_corp_latis_chatbot\utility\CommonModules\commonFunctions.js
#####  "crypto": "^1.0.1" : This module is used for Signing 
##### Files :
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\CAF\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoCreation\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoPrint\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoRecceipt\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoReceiving\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\SalesUpdate\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\ShipConfirmation\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\TimeEntry\service.js
    vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\TimeEntryServiceOrder\service.js

##### "ldapjs": "^2.2.4" : To make LDAP calls
##### File : 
vwt_corp_latis_chatbot\utility\CommonModules\commonFunctions.js

##### "request": "^2.88.2" : This module is used for making HTTP calls 
##### Files :   
  vwt_corp_latis_chatbot\utility\CommonModules\commonFunctions.js
  vwt_corp_latis_chatbot\utility\LatisModules\dbUtils.js
  vwt_corp_latis_chatbot\utility\LatisModules\services.js
  vwt_corp_latis_chatbot\utility\LatisModules\validations.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\CAF\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoCreation\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoPrint\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoReceipt\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\PoReceiving\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\SalesUpdate\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\ShipConfirmation\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\TimeEntry\service.js
  vwt_corp_latis_chatbot\utility\LatisModules\GuidedResolution\TimeEntryServiceOrder\service.js

       

