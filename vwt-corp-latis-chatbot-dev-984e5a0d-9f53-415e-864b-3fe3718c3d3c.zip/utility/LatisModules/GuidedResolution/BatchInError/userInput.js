const getAlias = require('../../Faqs/getAlias');
const Templates = require('../../../CommonModules/helperFunctions');
const intentNames = require('../../Constants/intentNames.json')
const DbCall = require('../../dbUtils')
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const commonFunctions=require('../../../CommonModules/commonFunctions')
const Services=require('../../services')
const webServiceCall=require('./service')
var count=1;
exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, batchInput;
    sessionAttributes.previousIntent=intentNames.batchErrorGuidedResolution;
    var pattern = "[0-9]{1,12}[/|,|-]([a-zA-Z]){2}"
    //date pattern is "[0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$"
    batchInput = userInput.match(pattern);
    if (batchInput) {
        count=1;
        await this.storeInput(intentRequest, callback, batchInput)
    }
    else {
        
        if (count <=3) {
            count++
            message = "Please enter your input in the below format\nBatch Number/Batch Type"
            if(sessionAttributes.SourceCode!=="en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
    }
}
exports.storeInput= async function (intentRequest, callback, batchInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var batchFormat;
    
    batchFormat= batchInput[0];
    let userInput = await Services.batchErrorFormat(batchFormat);
    sessionAttributes.batchNumber = userInput.BatchNumber;
    sessionAttributes.batchType = userInput.BatchType;
    
    sessionAttributes.previousIntent = null;
    let message = "batch in error details :" + "\n" + sessionAttributes.batchNumber + "\n" + sessionAttributes.batchType; 
    await Templates.getResponseTemplateFour(sessionAttributes, message, callback);


    //await webServiceCall.webServiceResponse(intentRequest,callback)
}