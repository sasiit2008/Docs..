'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const Services = require('../../services')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const commonResponseMessages = require('../../../CommonModules/commonResponseMessages')
const serviceParams = require('../../Constants/serviceRespParams.json')
const crypto = require('crypto');

exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
        var userId = credentials.userId;
        var password = credentials.password
         var privateKey = credentials.key;
        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        console.log("buff in po Receipt",bufdata);
        var sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        var signature = sign.toString('base64');
        console.log("signature", signature);
        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': auth,
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    console.log("this is jde lang", sessionAttributes.jdeLang)
    var response, message;
    var userInput = intentRequest.inputTranscript;
    var jsonInput = {
        "Order Number": sessionAttributes.orderNumber,
        "Order Type": sessionAttributes.orderType,
        "Order Company": sessionAttributes.orderCompany,
        "UseCase": "U04",
        "UserID": "FRCHAN0V9H",
        "Role": "R_RLW9805S",
        "Language": sessionAttributes.jdeLang
    }
    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.salesUpdate, intentRequest, callback);
        console.log("this is the service response", body);
        message = "Below are the issues which I found for your Order";
        console.log("this is result", body.Result)
        if (body.Result === false) {
            await errorMessages.dataNotAuthorised(intentRequest, callback)
        }
        else {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.salesUpdate, "error");
            if (response.resEn.length === 0) {
                response = await this.getResMessages(intentRequest, callback, body, serviceParams.salesUpdate, "success");
                if (response.resEn.length === 0) {
                    message = "No issue found during the initial investigation";
                }
            }
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
                message = message + response.resOt
            } else {
                message = message + response.resEn
            }


            var type = "Response";
            Session.setCurrentOutputType(sessionAttributes, type);
            sessionAttributes.Confirmation = "confirm";
            sessionAttributes.previousIntent = null;
            sessionAttributes.Confirmation = "guidedResolutionSnow";
            sessionAttributes.serviceNowFlow = "guidedResolution";
            sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Solution-SAL";
            sessionAttributes.shortDesc = "Error while matching receipt for " + userInput + +" (Order Number/Order Type/Order Company)";
            sessionAttributes.description = message;
            if (sessionAttributes.SourceCode !== "en") {
                var translatedMessage = await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description = message + "+" + translatedMessage
            }
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    } catch (error) {
        console.log("this is error in web service response", error);
        await errorMessages.generalError(intentRequest, callback);
    }

}

exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    let resEn = [];
    let resOt = [];
    let bodyDataYN, bodyDataOt, bodyDataEn, bodyDataVar;
    var sessionAttributes = intentRequest.sessionAttributes;
    let startIndex, endIndex;
    try {
        if (msgType === "success") {
            startIndex = serviceResp.sStartIndex;
            endIndex = serviceResp.sEndIndex;
        } else {
            startIndex = 0;
        }
        console.log(msgType);
        if (startIndex !== 0) {
            let flag = false;
            for (var i = startIndex; i <= endIndex; i++) {
                let index = i > 9 ? "_" + i : "_0" + i;
                index = (index === "_00") ? "" : index;
                console.log("index", index);
                if (i === 7 && flag === false) {
                    i = i - 1;
                    flag = true;
                    bodyDataYN = "Z_cErrorYN_U04_06_02_EV01"
                    bodyDataOt = "Z_szErrorDescOt_U04_06_02_DL"
                    bodyDataEn = "Z_szErrorDescEn_U04_06_02_DL"
                    bodyDataVar="Z_szVariable_U04_06_02_DL011"
                } else {

                    bodyDataYN = serviceResp.startKeyYN + index + serviceResp.endKeyYN;
                    console.log("this is body Data Yn", bodyDataYN);
                    bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.endKeyErrDesc;
                    console.log("this is body Data OT", bodyDataOt);
                    bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.endKeyErrDesc;
                    console.log("this is body Data En", bodyDataEn);
                    bodyDataVar = serviceResp.variableStartKey + index + serviceResp.variableEndKey
                }
                if (body[bodyDataYN] === "Y" || body[bodyDataYN] === "y") {

                    
                    if (bodyDataVar) {
                        var variable = "<" + bodyDataVar + ">"
                        console.log("this is variable")
                        console.log(variable);
                        if (body[bodyDataEn].includes(variable)) {
                            console.log("in if of includes")
                            variable = body[bodyDataEn].replace(variable, body[bodyDataVar])
                            resEn.push("\n" + "- " +variable + "\n" );
                        }
                        else {
                            console.log("in else of includes")
                            resEn.push("\n" + "- " + body[bodyDataEn] + "\n" + body[bodyDataVar]);
                        }
                    }
                    else {
                        resEn.push("- " + body[bodyDataEn] + "\n");
                    }
                    if (sessionAttributes.SourceCode !== "en") {
                        let otherLangMessage;
                        if (!body[bodyDataOt]) {
                            otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                        } else {
                            otherLangMessage = body[bodyDataOt];
                        }
                        otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                        if (bodyDataVar) {
                             var variable = "<" + bodyDataVar + ">"
                            console.log("this is variable")
                             console.log(variable);
                        if (body[bodyDataEn].includes(variable)) {
                            console.log("in if of includes")
                            variable = otherLangMessage.replace(variable, body[bodyDataVar])
                            resOt.push("\n" + "- " +variable + "\n" );
                            bodyDataVar = null;
                        }
                        else
                        {
                            resOt.push("\n" + "- " + otherLangMessage + "\n" + body[bodyDataVar]);
                            bodyDataVar = null;
                        }
                    }
                        else {
                            resOt.push("- " + otherLangMessage + "\n");
                        }
                    }
                }
            }

        }
        else {
            if (body.Z_cErrorYN_U04_EV01 === "Y" || body.Z_cErrorYN_U04_EV01 === "y") {
                resEn = "- " + body.Z_szErrorDescEn_U04_DL
                resEn = decodeURIComponent(JSON.parse('"' + resEn.replace(/\"/g, '\\"') + '"'))
                resOt = body.Z_szErrorDescOt_U04_DL;
                if (!resOt) {
                    console.log("came here", resOt);
                    resOt = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, resEn);
                }
                resOt = decodeURIComponent(JSON.parse('"' + resOt.replace(/\"/g, '\\"') + '"'))
                console.log("resString is", resOt);
                resOt = "- " + resOt + "\n";
            }

        }
        console.log("this is res En", resEn);
        console.log("this is res Ot", resOt);
        console.log("this is res en length", resEn.length);
        return {
            resEn: resEn,
            resOt: resOt
        }

    }
    catch (error) {
        console.log("this is error in  getMessage response", error)
        await errorMessages.generalError(intentRequest, callback)
    }

}
