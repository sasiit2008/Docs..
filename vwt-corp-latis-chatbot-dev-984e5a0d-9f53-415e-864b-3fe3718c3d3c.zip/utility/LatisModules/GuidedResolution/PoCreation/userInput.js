
const intentNames = require('../../Constants/intentNames.json');
const Templates = require('../../../CommonModules/helperFunctions');
const commonFunctions = require('../../../CommonModules/commonFunctions')
const errorMessages = require('../../../CommonModules/commonErrorMessages');
const webServiceCall=require('./service')
var count = 1;

exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var businessUnit
    var pattern = "[0-9]{7,12}"
    // this is incorrect way var Input = userInput.match(pattern);
    businessUnit = userInput.match(pattern)
    sessionAttributes.previousIntent = intentNames.poCreationGuidedResolution;
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (businessUnit && userInput.trim().length<=12) {
        count = 1;
        await this.storeInput(intentRequest, callback, businessUnit);
    }
    else {
        if (count <= 3) {
            count++
            sessionAttributes.currentCount = count;
            var message = "Please enter your Business Unit"
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            await errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
    }

}

exports.storeInput = async function (intentRequest,callback,businessUnit) {
    var sessionAttributes = intentRequest.sessionAttributes;
    console.log("this is business unit",businessUnit[0])
    sessionAttributes.bussinessUnit = businessUnit[0];
    sessionAttributes.currentCount = null;
    await webServiceCall.webServiceResponse(intentRequest,callback);
}