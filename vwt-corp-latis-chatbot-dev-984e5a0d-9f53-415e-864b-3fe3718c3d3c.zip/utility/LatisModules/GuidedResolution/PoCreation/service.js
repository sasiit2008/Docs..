'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const Services = require('../../services')
const serviceParams = require('../../Constants/serviceRespParams.json')
const crypto = require('crypto');
exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
        var userId = credentials.userId;
        var password = credentials.password;
        var privateKey = credentials.key;
        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        var sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        var signature = sign.toString('base64');
        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Authorization': auth,
                'Content-Type': 'application/json',
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        console.log("this is data", JSON.stringify(data))
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            console.log("this is data", JSON.stringify(data))
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
        throw new Error(error);
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var userInput = intentRequest.inputTranscript;
    var response
    console.log("this is session attributes business unit", sessionAttributes.bussinessUnit)
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    var jsonInput = {
        "Bussiness Unit": sessionAttributes.bussinessUnit,
        "Language": sessionAttributes.jdeLang,
        "Usecase":"U09" ,
        "UserID":"FFMBUS0V9M" ,
        "Role":"R_RLWF109S"
    }
    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.poCreation, intentRequest, callback);
        console.log("this is the service response", body)
        var message = "Below are the issues which I found for your Business Unit"
        if (body.Result === false) {
            await errorMessages.dataNotAuthorised(intentRequest,callback)
        }
        else
        {
        response = await this.getResMessages(intentRequest, callback, body, serviceParams.poCreation, "error");
        if (response.resEn.length === 0) {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.poCreation, "success");
            if (response.resEn.length === 0) {
                message = "No issue found during the initial investigation. Do you want me to log a ticket to investigate further";
            }
        }
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            message = message + "\n" + response.resOt.toString().replace(/,/g, '');
        } else {
            message = message + "\n" + response.resEn.toString().replace(/,/g, '');
        }

        var type = "Response";
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        sessionAttributes.Confirmation = "confirm";
        sessionAttributes.previousIntent = null;
        sessionAttributes.Confirmation = "guidedResolutionSnow"
        sessionAttributes.serviceNowFlow = "guidedResolution"
        sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Solution-STKPUR"
        sessionAttributes.shortDesc = "Error while creating PO for Business Unit" + userInput;
        sessionAttributes.description = message;
        if(sessionAttributes.SourceCode !== "en")
            {
                var translatedMessage= await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description=message+"+"+translatedMessage
            }
        await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    } catch (error) {
        console.log("this is error in web service response", error)
        await errorMessages.generalError(intentRequest, callback)
    }

}
exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    let resEn = [];
    let resOt = [];
    let bodyDataYN, bodyDataOt, bodyDataEn;
    let startIndex, endIndex;

 try{
    if (msgType === "success") {
        startIndex = serviceResp.sStartIndex;
        endIndex = serviceResp.sEndIndex;
    } else {
        startIndex = serviceResp.eStartIndex;
        endIndex = serviceResp.eEndIndex;
    }
    console.log(msgType);
    var sessionAttributes = intentRequest.sessionAttributes;
    for (let i = startIndex; i <= endIndex; i++) {
        let index = i > 9 ? "_" + i : "_0" + i;
        index = (index === "_00") ? "" : index;
        console.log("index", index);
        if (index) {
            bodyDataYN = serviceResp.startKeyYN + index + serviceResp.endKeyYN;
            console.log("this is body Data Yn", bodyDataYN);
            bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);
        } else {
            bodyDataYN = serviceResp.startKeyYN + index + serviceResp.failEndKey;
            console.log("this is body Data Yn", bodyDataYN);
            bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.failEndKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.failEndKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);
        }

        if (body[bodyDataYN] === "Y" || body[bodyDataYN] === "y" ) {
            resEn.push("- " + body[bodyDataEn] + "\n");
            if (sessionAttributes.SourceCode !== "en") {
                let otherLangMessage;
                if (!body[bodyDataOt]) {
                    otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                } else {
                    otherLangMessage = body[bodyDataOt];
                }
                otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                resOt.push("- " + otherLangMessage + "\n");
            }
        }
    }

    console.log("this is res En", resEn);
    console.log("this is res Ot", resOt);
    console.log("this is res en length", resEn.length);
    return {
        resEn: resEn,
        resOt: resOt
    }

   }
    catch (error) {
        console.log("this is error in  getMessage response", error)
        await errorMessages.generalError(intentRequest, callback)
     }

}
