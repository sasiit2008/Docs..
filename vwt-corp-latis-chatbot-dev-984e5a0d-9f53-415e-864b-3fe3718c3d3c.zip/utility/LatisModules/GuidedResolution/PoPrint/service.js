'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const Services = require('../../services')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const serviceParams = require('../../Constants/serviceRespParams.json')
const crypto = require('crypto');
exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userId,password,privateKey,sign,signature;
    console.log("session", sessionAttributes);
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
         userId = credentials.userId;
         password = credentials.password
         privateKey = credentials.key;
       
        console.log("the jsoninput", jsonInput);

        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        signature = sign.toString('base64');

        console.log("signature", signature);

        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Authorization': auth,
                'Content-Type': 'application/json',
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
        throw new Error(error);
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var response, message;
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var userInput = intentRequest.inputTranscript;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)  
    console.log("this is jde lang", sessionAttributes.jdeLang)
    console.log("the current session", intentRequest);

      var jsonInput = {
        "Order Number": sessionAttributes.orderNumber,
        "Order Type": sessionAttributes.orderType,
        "Order Company": sessionAttributes.orderCompany,
        "Language Preference": sessionAttributes.jdeLang,
        "USERID": sessionAttributes.UserIdJde,
        "ROLE": "R_RLWF013S",
        "Usecase": "U05"

    }


    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.poPrint, intentRequest, callback);
        console.log("this is the service response", body)
        message = "Below are the issues which I found for your Order";
        console.log("this is result", body.Result)
        if (body.Result === false) {
            message = body.Z_szErrorDesEn_U00_07_01_DL011
            message = decodeURIComponent(JSON.parse('"' + message.replace(/\"/g, '\\"') + '"'))
            if (sessionAttributes.SourceCode !== 'en') {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            }
            sessionAttributes.previousIntent = null;
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.poPrint, "error");
            if (response.resEn.length === 0) {
                response = await this.getResMessages(intentRequest, callback, body, serviceParams.poPrint, "success");
                if (response.resEn.length === 0) {
                    message = "No issue found during the initial investigation. Do you want me to log a ticket to investigate further";
                }
            }
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
                message = message + "\n" + response.resOt.toString().replace(/,/g, '');
            } else {
                message = message + "\n" + response.resEn.toString().replace(/,/g, '');
            }


            var type = "Response";
            Session.setCurrentOutputType(sessionAttributes, type);
            Session.setCurrentIntent(sessionAttributes, intentName);

            sessionAttributes.Confirmation = "confirm";
            sessionAttributes.previousIntent = null;
            sessionAttributes.Confirmation = "guidedResolutionSnow";
            sessionAttributes.serviceNowFlow = "guidedResolution";
            sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Solution-STKPUR";
            sessionAttributes.shortDesc = "Error while matching receipt for " + userInput+" (Order Number/Order Type/Order Company)";
            sessionAttributes.description = message;
            if(sessionAttributes.SourceCode !== "en")
            {
                var translatedMessage= await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description=message+"+"+translatedMessage
            }
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    } catch (error) {
        console.log("this is error in web service response", error)
        await errorMessages.generalError(intentRequest, callback)
    }

}
exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    console.log("the po ptrint value is",serviceResp);
    let resEn = [];
    let resOt = [];
    let startIndex, endIndex, bodyDataVar;
 try{
    if (msgType === "success") {
        startIndex = serviceResp.sStartIndex;
        endIndex = serviceResp.sEndIndex;
    } else {
        startIndex = 0;
    }
    console.log(msgType);
    var sessionAttributes = intentRequest.sessionAttributes;
    if (startIndex !== 0) {
        for (let i = startIndex; i <= endIndex; i++) {
            let index = i > 9 ? "_" + i : "_0" + i;
            console.log("this is index", index)
            let bodyDataYN = serviceResp.startKeyYN + index + serviceResp.endKeyYN;

            console.log("this is body Data Yn", bodyDataYN);
            let bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            let bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);

            if (body[bodyDataYN].toUpperCase() === "Y") {
                resEn.push("- " + body[bodyDataEn] + "\n");
            }
            if (body[bodyDataYN].toUpperCase() === "Y" && sessionAttributes.SourceCode !== "en") {
                let otherLangMessage;
                if (!body[bodyDataOt]) {
                    otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                } else {
                    otherLangMessage = body[bodyDataOt];
                }
                console.log("this is other language message", otherLangMessage)
                console.log("this is bodyDataVar", body[bodyDataVar])
                
               
                otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                resOt.push("- " + otherLangMessage + "\n");
            }
        }
    }
    else {
        if (body.Z_cErrorYN_U05_EV01 === "Y" || body.Z_cErrorYN_U05_EV01 === "y") {
            resEn = "- "+body.Z_szErrorDescEn_U05_DL011+"\n"
            resEn=decodeURIComponent(JSON.parse('"' + resEn.replace(/\"/g, '\\"') + '"'))
            resOt = body.Z_szErrorDescOt_U05_DL011;

                    if(!resOt){
                        console.log("came here",resOt);
                        resOt = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body.Z_szErrorDescEn_U05_DL011);
                     }
            resOt = decodeURIComponent(JSON.parse('"' + resOt.replace(/\"/g, '\\"') + '"'))
            console.log("resString is", resOt);
            resOt="- "+resOt+"\n";
           
           
        }
    }
    console.log("this is res En", resEn);
    console.log("this is res Ot", resOt);
    console.log("this is res en length", resEn.length);
    return {
        resEn: resEn,
        resOt: resOt
    }
}
  catch (error) {
        console.log("this is error in  getMessage response", error)
        await errorMessages.generalError(intentRequest, callback)
   }


}