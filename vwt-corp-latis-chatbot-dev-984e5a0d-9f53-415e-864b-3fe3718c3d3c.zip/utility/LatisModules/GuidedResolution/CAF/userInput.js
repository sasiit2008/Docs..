const intentNames = require('../../Constants/intentNames.json');
const Templates = require('../../../CommonModules/helperFunctions');
const commonFunctions = require('../../../CommonModules/commonFunctions')
const errorMessages = require('../../../CommonModules/commonErrorMessages');
const Services = require('../../services');
const dbCall = require('../../dbUtils')
const webServiceCall = require('./service')
var count = 1;
var cafCount = 1;

exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, cafInput
    sessionAttributes.previousIntent = intentNames.cafGuidedResolution;
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (sessionAttributes.cafMenuTriggered) {
        console.log("caf menu is triggered", sessionAttributes.cafMenuTriggered)
        sessionAttributes.cafMenuTriggered = null;
        var validateCaf = await Services.validateCaf(intentRequest, callback, userInput)
        
        if (validateCaf) {
            cafCount = 1;
            await webServiceCall.webServiceResponse(intentRequest, callback)
        }
        else {
            await this.cafError(intentRequest, callback)

        }

        
    }
    else {
        var pattern = "([a-zA-Z0-9]){1,12}[/|,|-|.][a-zA-Z0-9]{1,6}[/|,|-|.][a-zA-Z0-9]{1,8}"
        cafInput = userInput.match(pattern);
        var validateInput= await Services.validateCafInput(userInput)
        if (cafInput && validateInput) {
            count = 1;
            await this.storeInput(intentRequest, callback, cafInput,userInput)
        }
        else {

            if (count <= 3) {
                count++
                sessionAttributes.currentCount = count;
                message = "Please enter your input in the below format\nProject Number/Object Account/Subsidiary (Ex: 1500200003/624100/21850089)"
                if (sessionAttributes.SourceCode !== "en") {
                    message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
                }
                sessionAttributes.OutputType = "shortDescription";
                await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
            }
            else {
                count = 1;
                sessionAttributes.currentCount = null;
                errorMessages.exhaustAttempts(intentRequest, callback)
            }

        }
    }
}
exports.storeInput = async function (intentRequest, callback, cafInput,userInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var cafData, inputFormat;
    inputFormat = cafInput[0];
    cafData = await Services.cafInputFormat(inputFormat);
    sessionAttributes.projectNumber = cafData.projectNumber;
    sessionAttributes.objectAccount = cafData.accountNumber;
    sessionAttributes.subsidiary=cafData.subsidiary;
    sessionAttributes.cafUserInput=userInput
    sessionAttributes.currentCount = null;
    await this.cafSubModule(intentRequest, callback);
}

exports.cafSubModule = async function (intentRequest, callback) {
    var ButtonData, translatedMenu, message, translatedButtonText;
    var otherLangMenu = [], menuItems = [], menuItemsEn = [], btn = [];
    var sessionAttributes = intentRequest.sessionAttributes;
    console.log("came in cafsubmodule");
    try {
        // Fetch the Cafsubmodulemenu options from the table
        const results = await dbCall.callMenuTable('CAFSubModule', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('CAFSubModule', 'en');
        if (results) {
            menuItems = results.Item.Items.L;
            menuItemsEn = resultsEn.Item.Items.L;
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.name.S
                    var menuEn = menuItemsEn[i].M.name.S
                    btn.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        }
        else {
            menuItems = resultsEn.Item.Items.L;
            menuItems.forEach(e => {
                otherLangMenu.push(e.M.name.S)
            })
            var menuStr = otherLangMenu.toString(); //menu array to string
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, menuStr);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split(",");
            }
            for (var j = 0; j < menuItems.length; j++) {
                btn.push({
                    text: translatedMenu[j],
                    Value: menuItems[j].M.name.S,
                });
            }

        }
        message = "Please select a valid option from this menu"
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
        }

        ButtonData = Templates.getButtons(btn);
        sessionAttributes.cafMenuTriggered = 'yes'
        return Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
}
exports.cafError = async function (intentRequest, callback) {
    if (cafCount <= 3) {
        cafCount++
        await this.cafSubModule(intentRequest, callback)
    }
    else {
        cafCount = 1;
        errorMessages.exhaustAttempts(intentRequest, callback)
    }
}
