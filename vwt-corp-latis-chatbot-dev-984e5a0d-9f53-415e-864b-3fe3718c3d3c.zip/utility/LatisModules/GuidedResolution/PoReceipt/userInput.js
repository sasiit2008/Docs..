const getAlias = require('../../Faqs/getAlias');
const Templates = require('../../../CommonModules/helperFunctions');
const intentNames = require('../../Constants/intentNames.json')
const DbCall = require('../../dbUtils')
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const commonFunctions=require('../../../CommonModules/commonFunctions')
const Services=require('../../services')
const webServiceCall=require('./service')
var count=1;
exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, poReceiptInput;
    sessionAttributes.previousIntent=intentNames.voucherMatchGuidedResolution;
    var pattern = "[0-9]{1,8}[/|,|-]([a-zA-Z0-9]){2}[/|,|-][a-zA-Z0-9]{1,5}[/|,|-][0-9]{1,8}[/|,|-][a-zA-Z]{2}[/|,|-][0-9]{1,5}[/|,|-][0-9]{1,2}"
    //date pattern is "[0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$"
    poReceiptInput = userInput.match(pattern);
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (poReceiptInput) {
        count=1;
        await this.storeInput(intentRequest, callback, poReceiptInput)
    }
    else {
        
        if (count <=3) {
            count++
            sessionAttributes.currentCount = count;
            message = "Please enter your input in the below format\nOrder Number/Order Type/Order Company/Voucher Number/Voucher Type/Voucher Company/Line Number"
            if(sessionAttributes.SourceCode!== "en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
    }
}
exports.storeInput= async function (intentRequest, callback, poReceiptInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var poFormat;
    
    poFormat= poReceiptInput[0];
    let userInput = await Services.poReceiptFormat(poFormat);
    sessionAttributes.orderNumber = userInput.OrderNumber;
    sessionAttributes.orderType = userInput.OrderType;
    sessionAttributes.orderCompany = userInput.OrderCompany;
    sessionAttributes.voucherNumber = userInput.VoucherNumber
    sessionAttributes.VoucherCompany = userInput.VoucherCompany
    sessionAttributes.voucherType= userInput.VoucherType
    sessionAttributes.lineNumber=userInput.LineNumber
    sessionAttributes.currentCount = null;

    await webServiceCall.webServiceResponse(intentRequest,callback)
}