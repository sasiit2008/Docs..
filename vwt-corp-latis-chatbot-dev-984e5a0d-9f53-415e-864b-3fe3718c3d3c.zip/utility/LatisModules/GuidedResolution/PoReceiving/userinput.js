const intentNames = require("../../Constants/intentNames.json");
const Templates = require("../../../CommonModules/helperFunctions");
const commonFunctions = require("../../../CommonModules/commonFunctions");
const errorMessages = require("../../../CommonModules/commonErrorMessages");
const Services = require("../../services");
const webServiceCall = require('./service')
var count = 0;

exports.validateInput = async function (intentRequest, callback) {
  console.log("validate the user input po matching is");
  console.log(intentRequest);
  var sessionAttributes = intentRequest.sessionAttributes;
  var userInput = intentRequest.inputTranscript;
  console.log("the user input is", userInput);
  var pattern =
    "[0-9]{1,8}[/|,|-]([a-zA-Z0-9]){2}[/|,|-][a-zA-Z0-9]{1,5}[/|,|-][0-9]{1,2}";
  var Input = userInput.match(pattern);
  let validateInput = await Services.validatePoReceiving(userInput)
  sessionAttributes.previousIntent = intentNames.poReceiptGuidedResolution;
  if (!sessionAttributes.currentCount) {
    console.log("no such curret count key");
    count = 1;
  }
  if (Input && validateInput) {
    this.storeInput(intentRequest, Input, callback);
  } else {
    if (count <= 3) {
      count++;
      sessionAttributes.currentCount = count;
      console.log("message is taken");
      var message =
        "Please enter in below format\nOrder Number / Order Type / Order Company / Line Number ";
      if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunctions.modeltranslation(
          sessionAttributes.SourceCode,
          message
        );
      }
      sessionAttributes.OutputType = "shortDescription";
      await Templates.getResponseTemplateFour(
        sessionAttributes,
        message,
        callback
      );
    } else {
      sessionAttributes.currentCount = null;
      count = 1;
      errorMessages.exhaustAttempts(intentRequest, callback);
    }
  }
};

exports.storeInput = async function (intentRequest, Input, callback) {
  console.log("the store from matching receipt");
  var sessionAttributes = intentRequest.sessionAttributes;
  console.log("the input is", Input);
  let inputFormat = Input[0];
  let userInput = await Services.poReceivingInput(inputFormat);
  sessionAttributes.PoReceivedOrderNumber = userInput.orderNumber;
  sessionAttributes.PoReceivedOrderType = userInput.orderType;
  sessionAttributes.PoReceivedOrderCompany = userInput.orderCompany;
  sessionAttributes.PoReceivedLineNumber = userInput.lineNumber;
  sessionAttributes.previousIntent = null;
  sessionAttributes.currentCount = null;
  //   let message =
  //     " poreceiving details :" +
  //     "\n" +
  //     sessionAttributes.PoReceivedOrderNumber +
  //     "\n" +
  //     sessionAttributes.PoReceivedOrderType +
  //     "\n" +
  //     sessionAttributes.PoReceivedOrderCompany +
  //     "\n" +
  //     sessionAttributes.PoReceivedLineNumber;
  //   await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
  await webServiceCall.webServiceResponse(intentRequest, callback)
};
