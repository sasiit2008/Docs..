'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const Services = require('../../services')
const crypto = require('crypto');
exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    try {
        let credentials=await commonFunctions.getCredentials(intentRequest,callback)
        var userId= credentials.userId;
        var password= credentials.password;
        var privateKey = credentials.key;
        console.log("the json input", jsonInput);
       
          const bufdata = Buffer.from(JSON.stringify(jsonInput));
          console.log("buff",bufdata);
        var sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        var signature = sign.toString('base64');
        console.log("signature", signature);

        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Authorization': auth,
                'Content-Type': 'application/json',
                'jde-AIS-Auth-Environment':sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        console.log("this is data",JSON.stringify(data))
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
        throw new Error(error);
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    var jsonInput = {
        "Order Number": sessionAttributes.orderNumber,
        "Order Type": sessionAttributes.orderType,
        "Order Company": sessionAttributes.orderCompany,
        "Line Number": sessionAttributes.lineNumber,
        "Language Preference": sessionAttributes.jdeLang
    }
    console.log(jsonInput);
    console.log(JSON.stringify(jsonInput));
    
    
    try {
        let body = await this.callWebService(jsonInput, urls.shipmentConfirmation, intentRequest, callback);
        console.log("this is the service response", body)
        await this.displayMessage(intentRequest, callback, body)
    } catch (error) {
        console.log("this is error in web service response", error)
        await errorMessages.generalError(intentRequest, callback)
    }

}
exports.displayMessage = async function (intentRequest, callback, body) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var userInput = intentRequest.inputTranscript;
    var AppState = intentName
    var errorDesc1, errorDesc2, errorDesc3, errorDesc4, orderMissing,sessionMessage;
    var type = "Response";
    sessionAttributes.Confirmation = "confirm";
    sessionAttributes.previousIntent = null;
    var message = "Below are the issues which I found for your shipment:"
try{
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
        errorDesc1 = (body.Z_cErrorFlag_U07_05_EV01 === "Y") ? body.Z_szErrorDescOt_U07_05_DL011 : ""
        errorDesc2 = (body.Z_cErrorFlag_U07_06_EV01 === "Y") ? body.Z_szErrorDescOt_U07_06_DL011 : ""
        errorDesc3 = (body.Z_cErrorFlag_U07_07_EV01 === "Y") ? body.Z_szErrorDescOt_U07_07_DL011 : ""
        errorDesc4 = (body.Z_cErrorFlag_U07_08_EV01 === "Y") ? body.Z_szErrorDescOt_U07_08_DL011 : ""
        orderMissing = (body.Z_cErrorFlag_U07_EV01 === "Y") ? body.Z_szErrorDescOt_U07_DL011 : null
    }
    else {
        errorDesc1 = (body.Z_cErrorFlag_U07_05_EV01 === "Y") ? body.Z_szErrorDescEn_U07_05_DL011 : ""
        errorDesc2 = (body.Z_cErrorFlag_U07_06_EV01 === "Y") ? body.Z_szErrorDescEn_U07_06_DL011 : ""
        errorDesc3 = (body.Z_cErrorFlag_U07_07_EV01 === "Y") ? body.Z_szErrorDescEn_U07_07_DL011 : ""
        errorDesc4 = (body.Z_cErrorFlag_U07_08_EV01 === "Y") ? body.Z_szErrorDescEn_U07_08_DL011 : ""
        orderMissing = (body.Z_cErrorFlag_U07_EV01 === "Y") ? body.Z_szErrorDescEn_U07_DL011 : null
    }

    if (orderMissing) {
        type = "Menu"
        message = "I cannot find the order based on the Order Number you entered.For any other assistance Please type 'Help'"
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
        }
    }
    else if (errorDesc1 || errorDesc2 || errorDesc3 || errorDesc4) {
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
        }
        if (errorDesc1)
            message = message + "\n" + "- " + errorDesc1
        if (errorDesc2)
            message = message + "\n" + "- " + errorDesc2
        if (errorDesc3)
            message = message + "\n" + "- " + errorDesc3
        if (errorDesc4)
            message = message + "\n" + "- " + errorDesc4
    }
    else {
        message = "No issue found during the initial investigation. Do you want me to log a ticket to investigate further"
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
        }
    }

    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);
    sessionAttributes.Confirmation = "guidedResolutionSnow"
    sessionAttributes.serviceNowFlow = "guidedResolution"
    sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Solution-SAL"
    sessionAttributes.shortDesc = "Ship Confirmation issue for " + userInput;
    if(sessionAttributes.SourceCode !=="en")
    {
        var translatedMessage=await commonFunctions.modeltranslation("en", message)
        sessionMessage=message+ "+" + translatedMessage
        sessionAttributes.description = sessionMessage
    }
    else
    {
    sessionAttributes.description = message;
    }
    await Templates.getResponseTemplateFour(sessionAttributes, message, callback);

 }
 catch (error) {
    console.log("this is error in  getMessage response", error)
    await errorMessages.generalError(intentRequest, callback)
    }
}
