'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const Services = require('../../services')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const commonResponseMessages = require('../../../CommonModules/commonResponseMessages')
const serviceParams = require('../../Constants/serviceRespParams.json')
const crypto = require('crypto');
exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userId,password,privateKey,sign,signature;
    console.log("session", sessionAttributes);
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
        userId = credentials.userId;
        password = credentials.password
        privateKey = credentials.key;
       
        console.log("the jsoninput", jsonInput);

        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        signature = sign.toString('base64');

        console.log("signature", signature);

        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': auth,
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            console.log("this is data", JSON.stringify(data))
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    console.log("this is jde lang", sessionAttributes.jdeLang)
    var response, message;
    var userInput = intentRequest.inputTranscript;
    var jsonInput = {
        "Project Number": sessionAttributes.projectNumber,
        "Adress Number": sessionAttributes.addressNumber,
        "Work Date": sessionAttributes.workDate,
        "Language": sessionAttributes.jdeLang,
        "UserID": sessionAttributes.UserIdJde,
        "Role": sessionAttributes.Role,
        "UseCase": "U03"
    }
    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.timeEntry, intentRequest, callback);
        console.log("this is the service response", body);
        message = "Below are the issues which I found for your Time Entry";
        if (body.Result === false) {
            message = body.Z_szErrorDesEn_U00_07_01_DL011
            message = decodeURIComponent(JSON.parse('"' + message.replace(/\"/g, '\\"') + '"'))
            if (sessionAttributes.SourceCode !== 'en') {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            }
            sessionAttributes.previousIntent = null;
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else
        {
        response = await this.getResMessages(intentRequest, callback, body, serviceParams.timeEntry, "error");
        if (response.resEn.length === 0) {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.timeEntry, "success");
            if (response.resEn.length === 0) {
                message = "No issue found during the initial investigation. Do you want me to log a ticket to investigate further";
            }
        }
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            message = message + "\n" + response.resOt.toString().replace(/,/g, '');
        } else {
            message = message + "\n" + response.resEn.toString().replace(/,/g, '');
        }


        var type = "Response";
        Session.setCurrentOutputType(sessionAttributes, type);
        sessionAttributes.Confirmation = "confirm";
        sessionAttributes.previousIntent = null;
        sessionAttributes.Confirmation = "guidedResolutionSnow";
        sessionAttributes.serviceNowFlow = "guidedResolution";
        sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Finance-TE";
        sessionAttributes.shortDesc = "Time Entry Issue for " + userInput +" (Project Number /Address Number/Work Date)"
        sessionAttributes.description = message;
        if(sessionAttributes.SourceCode !== "en")
            {
                var translatedMessage= await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description=message+"+"+translatedMessage
            }
        await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    } catch (error) {
        console.log("this is error in web service response", error);
        await errorMessages.generalError(intentRequest, callback);
    }

}

exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    let resEn = [];
    let resOt = [];
    let startIndex, endIndex, bodyDataVar;
try{
    if (msgType === "success") {
        startIndex = serviceResp.sStartIndex;
        endIndex = serviceResp.sEndIndex;
    } else {
        startIndex = serviceResp.eStartIndex;
        endIndex = serviceResp.eEndIndex;
    }
    console.log(msgType);
    var sessionAttributes = intentRequest.sessionAttributes;
    if (startIndex !== 0) {
        for (let i = startIndex; i <= endIndex; i++) {
            let index = i > 9 ? "_" + i : "_0" + i;
            console.log("this is index", index)
            let bodyDataYN = serviceResp.startKeyYN + index + serviceResp.endKeyYN;

            console.log("this is body Data Yn", bodyDataYN);
            let bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            let bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);

            if (body[bodyDataYN].toUpperCase() ==="Y") {
                if (index === "_02" || index === "_03") {
                    bodyDataVar = serviceResp.variableStartKey + index + serviceResp.variableEndKey
                    console.log("this is body data var", body[bodyDataVar])
                    if (bodyDataVar)
                        resEn.push("- " + body[bodyDataEn] + "\n" + body[bodyDataVar] + "\n");
                }
                else if (index === "_04" || index === "_05") {
                    bodyDataVar = serviceResp.variableStartKey + index + serviceResp.variableEndKeyExtn
                    if (bodyDataVar)
                        resEn.push("- " + body[bodyDataEn] + "\n" + body[bodyDataVar] + "\n");
                }
                else {
                    resEn.push("- " + body[bodyDataEn] + "\n");
                }
                if (sessionAttributes.SourceCode !== "en") {
                    let otherLangMessage;
                    if (!body[bodyDataOt]) {
                        otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                    } else {
                        otherLangMessage = body[bodyDataOt];
                    }
                    otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                    console.log("this is other lang message", otherLangMessage)
                    console.log("this is bodyDataVar", body[bodyDataVar])
                    if (bodyDataVar) {
                        resOt.push("- " + otherLangMessage + "\n" + body[bodyDataVar] + "\n");
                        bodyDataVar = null;
                    }
                    else {
                        resOt.push("- " + otherLangMessage + "\n");
                    }
                }
            }
        }
    }
    console.log("this is res En", resEn);
    console.log("this is res Ot", resOt);
    console.log("this is res en length", resEn.length);
    return {
        resEn: resEn,
        resOt: resOt
    }
 }
 catch (error) {
    console.log("this is error in  getMessage response", error)
    await errorMessages.generalError(intentRequest, callback)
    }
}

