const getAlias = require('../../Faqs/getAlias');
const Templates = require('../../../CommonModules/helperFunctions');
const intentNames = require('../../Constants/intentNames.json')
const DbCall = require('../../dbUtils')
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const commonFunctions=require('../../../CommonModules/commonFunctions')
const Services=require('../../services')
const webServiceCall=require('./service')
var count=1;
exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, timeEntryInput,validateInput;
    sessionAttributes.previousIntent=intentNames.timeEntryGuidedResolution;
    sessionAttributes.intentStage ='timeInput'
    var pattern = "[a-zA-Z0-9]{1,12}[/|,|-]([0-9]){1,8}[/|,|-][0-9]{2}[/|,|-][0-9]{2}[/|,|-][0-9]{4}"
    //date pattern is "[0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$"
    timeEntryInput = userInput.match(pattern);
    validateInput= await Services.validateTimeEntryInput(userInput)
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (timeEntryInput && validateInput) {
        count=1;
        await this.storeInput(intentRequest, callback, timeEntryInput)
    }
    else {
        if (count <=3) {
            count++
            sessionAttributes.currentCount = count;
            message = "Please enter your input in the below format\nProject Number /Address Number/Work Date (MM-DD-YYYY) (Ex:109050400/1910911/11-23-2020)"
            if(sessionAttributes.SourceCode!== "en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
    }
}
exports.storeInput= async function (intentRequest, callback, timeEntryInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var inputFormat, addressNumber, workDate, projectNumber;
    sessionAttributes.intentStage=null;
    inputFormat= timeEntryInput[0];
    let userInput = await Services.timeEntryFormat(inputFormat);
    projectNumber = userInput.ProjectNumber;
    addressNumber = userInput.AddressNumber;
    workDate = userInput.WorkDate;
    sessionAttributes.projectNumber = projectNumber;
    sessionAttributes.addressNumber = addressNumber;
    sessionAttributes.workDate = workDate;
    sessionAttributes.currentCount = null;
    await webServiceCall.webServiceResponse(intentRequest,callback)

}