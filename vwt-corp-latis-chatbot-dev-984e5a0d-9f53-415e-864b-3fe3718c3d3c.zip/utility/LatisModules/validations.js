'use strict';
let request = require("request");
let util = require('util');
request = util.promisify(request);
//Importing the modules
const commonFunction = require('../CommonModules/commonFunctions');
const urlConstants = require('./Constants/Urls.json');
const services  = require('./services');

exports.userValidation = async function (sessionAttributes) {
    // Check if it is coming from a LATIS origin
    let hostNameCheck = (sessionAttributes.Hostname === urlConstants.latisDevUrl) ? true : false;
    let e1AppStateCheck = sessionAttributes.e1AppStateJde ? true : false;
    let userIdJdeCheck = sessionAttributes.UserIdJde ? true : false;
    let uservalidation
    if (hostNameCheck && e1AppStateCheck && userIdJdeCheck) {
        uservalidation = await this.validateUser(sessionAttributes);
    }
    else {
        console.log("hostname is",hostNameCheck)
        uservalidation = false
    }
    return uservalidation;
}

exports.validateUser = async function (sessionAttributes) { 
    console.log("Validate User");
    let userIdValid =  await services.validateUserId(sessionAttributes);
    console.log("the user ID validation from services", userIdValid);
    if(userIdValid){
       let  userValidation = await commonFunction.callLdapQuery(sessionAttributes.UserIdJde);
       if(userValidation.length > 0){
                    sessionAttributes.userMail = userValidation[0].mail;
                    sessionAttributes.country = userValidation[0].co
                    sessionAttributes.userName = userValidation[0].givenName
                    sessionAttributes.userAccountControl = userValidation[0].userAccountControl;
                    //Check if the email id is fetched from LDAP
                    sessionAttributes.validation = sessionAttributes.userMail ? true : false;
                    return sessionAttributes.validation
                }else{
                     sessionAttributes.validation =  false;
                     return sessionAttributes.validation
                }
    }else{
        sessionAttributes.validation =  false;
        return sessionAttributes.validation;
    }

}