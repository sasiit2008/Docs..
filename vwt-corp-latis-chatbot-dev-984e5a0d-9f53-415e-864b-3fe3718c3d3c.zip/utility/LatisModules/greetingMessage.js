'use strict';
//importing node modules
let request = require("request");
let util = require('util');
request = util.promisify(request);
const AWS = require('aws-sdk');

// Configuring AWS module paramaters
AWS.config.update({ region: "eu-west-1" });
const dynamoDB = new AWS.DynamoDB();
const service = require('./services');

// Importing Functional Modules
const Templates = require('../CommonModules/helperFunctions');
const dbCall = require('./dbUtils')
const commonFunction = require('../CommonModules/commonFunctions')
const CommonError = require('../CommonModules/commonErrorMessages')
const Session = require("./session");
const constants=require('./Constants/constants.json')

//Send the Greeting Response to the user
exports.modelGreetingResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var message = "Hi" + " " + sessionAttributes.userName + "," + "Welcome to LATIS chatbot";
    var message2 = "";
    //Fetch the language of the user stored in Language table
    try {
        var checkLang = await dbCall.fetchLang(sessionAttributes.UserIdJde, sessionAttributes);
        //If Language Doesn't exist in the table
        if (!checkLang) {

            message2 = "^Your default langauge is 'English'.If you want to change your language, Please type 'Change language'";
            // If the User id exists in the table or not
            if (!sessionAttributes.userIdDb) {
                // If User Id doesn't exists, then insert the user id in table
                let userIdValid = await service.validateUserId(sessionAttributes);
                if(userIdValid){
                    await dbCall.updateUserId(sessionAttributes.UserIdJde);
                }else{
                    CommonError.userOperation(intentRequest, callback);
                }
               
            }
        }
        var greetingMessage = message + message2;
        const type = "Menu";
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        sessionAttributes.OutputType = "Greet";
        if (sessionAttributes.SourceCode !== "en") {
            var translatedMessage = await commonFunction.modeltranslation(sessionAttributes.SourceCode, greetingMessage);
            var translatedTitle=await commonFunction.modeltranslation(sessionAttributes.SourceCode, constants.userGuideTitle);
            return Templates.getResponseCardTemplateThree(sessionAttributes, translatedMessage,constants.userGuideLink, translatedTitle, callback);
        } else {
            return Templates.getResponseCardTemplateThree(sessionAttributes, greetingMessage,constants.userGuideLink, constants.userGuideTitle, callback);
        }
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
};

// Function to change the language of the user
exports.modelChangeLanguage = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    const slots = intentRequest.currentIntent.slots;
    var intentName = intentRequest.currentIntent.name;
    var message;
    // Call the update language database utility 
    try {
        var changeLang;
        let userIdValid = service.validateUserId(sessionAttributes);
        console.log("in the model change language", userIdValid);
        if(userIdValid){
          changeLang = await dbCall.updateLang(slots.Lang, sessionAttributes.UserIdJde,callback);
        }else{
             CommonError.userOperation(intentRequest, callback);
        }
  
        if (changeLang) {
            message = "Your language has been successfully updated.";
            message = await commonFunction.modeltranslation(slots.Lang, message);
        } else {
            message = "I am facing some issues while updating your language";
        }
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentAppState(sessionAttributes, AppState);
        return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
};


