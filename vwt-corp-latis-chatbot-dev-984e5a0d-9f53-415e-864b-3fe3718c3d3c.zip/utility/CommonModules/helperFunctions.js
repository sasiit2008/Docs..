var exports = module.exports = {};
const fs = require('fs');

// ---------------- Helper Functions --------------------------------------------------

//function for  responsecard with multiple buttons - Version One -10 options
exports.getResponseCardTemplateOne =  function(sessionAttributes, message , ButtonData , ButtonData1, callback){
    callback(elicitIntent(sessionAttributes,
        { contentType: 'PlainText', content: message },
        {
            version: '1',
            contentType: "application/vnd.amazonaws.card.generic", genericAttachments: [
                {
          
                    buttons: ButtonData,
                },
                {
                    buttons: ButtonData1,
                }
            ]
        },
    ));
}

//function for  responsecard with multiple buttons - Version Two
exports.getResponseCardTemplateTwo = function(sessionAttributes, message , ButtonData , callback){
    callback(elicitIntent(sessionAttributes,
        { contentType: 'PlainText', content: message },
        {
            version: '1',
            contentType: "application/vnd.amazonaws.card.generic", genericAttachments: [
                {
                   
                    buttons: ButtonData,
                }
            ]
        },
    ));
}

//function for responsecard with url and title - Version Three
exports.getResponseCardTemplateThree = function(sessionAttributes, message , url ,  title , callback){
    callback(elicitIntent(sessionAttributes,
        { contentType: 'PlainText', content: message },
        {
            version: '2',
            contentType: "application/vnd.amazonaws.card.generic", genericAttachments: [
                {
                    title: title,
                    attachmentLinkUrl: url,
                }
            ]
        },
    ));
}

//function for normal message content - Version Four
exports.getResponseTemplateFour = function (sessionAttributes, message , callback){
    callback(elicitIntent(sessionAttributes,
        { contentType: 'PlainText', content: message },
    ));
}

//function for normal message content with close function- Version Five
exports.getCloseResponseTemplate = function(sessionAttributes,  message , callback){
    callback(close(sessionAttributes, 'Fulfilled',
        { contentType: 'PlainText', content: message },
    ));
}

exports.getCustomResponseTemplate = function(sessionAttributes, message, callback){
    callback(elicitIntent(sessionAttributes, 
        { contentType: 'CustomPayload', content: message }, 
    ));
}

//function for  responsecard with multiple buttons for elicit slot - Version Six
exports.getElicitSlotResponseCardTemplate = function(sessionAttributes, intentName, slots, slotToElicit , message , ButtonData , callback){
    callback(elicitSlot(sessionAttributes, intentName, slots, slotToElicit,
        { contentType: 'PlainText', content: message },
        {
            version: '1',
            contentType: "application/vnd.amazonaws.card.generic", genericAttachments: [
                {
                    buttons: ButtonData,
                }
            ]
        }
    ));
}

//function for  responsecard with no buttons for elicit slot - Version Seven
exports.getElicitSlotTemplate = function(sessionAttributes, intentName, slots, slotToElicit , message , callback){
    callback(elicitSlot(sessionAttributes, intentName, slots, slotToElicit,
        { contentType: 'PlainText', content: message }));
    return;
}

//for reading JSON data
exports.getJson = function() {
    let rawdata = fs.readFileSync('./utility/constants.json');
    return JSON.parse(rawdata);
}

//funtion to generate button in Response Card
exports.getButtons = function(options) {
    var buttons = [];
    options.forEach(option => {
        buttons.push({
            text: option.text,
            value: option.Value
        });
    });
    console.log(buttons)
    return buttons;
}

// --------------- Helpers that build all of the responses -----------------------

function elicitSlot(sessionAttributes, intentName, slots, slotToElicit, message, responseCard) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'ElicitSlot',
            intentName,
            slots,
            slotToElicit,
            message,
            responseCard
        },
    };
}

function elicitIntent(sessionAttributes, message, responseCard) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'ElicitIntent',
            message,
            responseCard,
        },
    };
}

function close(sessionAttributes, fulfillmentState, message, responseCard) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Close',
            fulfillmentState,
            message,
            responseCard
        },
    };
}



