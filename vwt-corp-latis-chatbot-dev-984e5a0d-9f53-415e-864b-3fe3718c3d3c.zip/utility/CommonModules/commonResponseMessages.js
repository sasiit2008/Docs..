'use strict';
// Importing the Functional Modules
const commonFunction = require('./commonFunctions')
const errorMessages = require('./commonErrorMessages')
const Templates = require("./helperFunctions");
const dbCall = require('../LatisModules/dbUtils')
const Session = require("../LatisModules/session");

// Triggered when user needs click on 'Yes' of Do you need any other assistance
exports.modelFurtherAssistanceHelp = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    try {
        var message = "Sure, Please type your query or type help";
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
        }
        const type = "Menu";
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);

        Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
// Triggers after the user receives any valid answer
exports.modelResponse = async function (intentRequest, callback) {
    var btnYesNo = [];
    var menuItems, menuItemsEn, ButtonData, translatedButtonText, translatedMenu
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    const type = "Menu";
    sessionAttributes.Confirmation = "satisfied";
    var message = "Are you satisfied with the response?";
    try {
        // Fetches the Yes No Menu Options from the table on the basis of Language
        const results = await dbCall.callMenuTable('Menu', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('Menu', 'en');
        if (results) {
            menuItems = results.Item.SubModule.L
            menuItemsEn = resultsEn.Item.SubModule.L
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.SubModuleName.S
                    var menuEn = menuItemsEn[i].M.SubModuleName.S
                    btnYesNo.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        }
        else {
            // If no custom translation then this block will be executed
            menuItems = resultsEn.Item.SubModule.L;
            var menuStr = menuItems.toString(); //menu array to string
            menuStr = menuStr.toLowerCase().replace(/,/g, "/");
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split("/");
            }
            for (var j = 0; j < menuArr.length; j++) {
                btnYesNo.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }

        }
        ButtonData = Templates.getButtons(btnYesNo);
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
        }
        Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
exports.notSatisfiedInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    try {
            message = "I apologize for not being able to help you. Please enter the reason for not being satisfied.";
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        sessionAttributes.Confirmation='notSatisfiedInput'
        sessionAttributes.OutputType = "shortDescription";
        return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
//response when the user is not satisfied
exports.modelResponseNo = async function (intentRequest, callback) {
    var btnYesNo = [];
    var translatedMenu, translatedButtonText, message, menuItems, menuItemsEn, ButtonData,menuStr;
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    try {
        // Fetches the Menu Options from the table
        const results = await dbCall.callMenuTable('Menu', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('Menu', 'en');
        if (results) {
            menuItems = results.Item.SubModule.L
            menuItemsEn = resultsEn.Item.SubModule.L
            message = results.Item.IncidentMessage.S
            console.log("menu items before loop", JSON.stringify(menuItems))
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.SubModuleName.S
                    var menuEn = menuItemsEn[i].M.SubModuleName.S
                    btnYesNo.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        }
        else {
            menuItems = resultsEn.Item.SubModule.L;
            menuStr = menuItems.toString();
            message = results.Item.IncidentMessage.S
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split("/");
            }
            for (var j = 0; j < menuArr.length; j++) {
                btnYesNo.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }

        }
        ButtonData = Templates.getButtons(btnYesNo);
        const type = "Menu";
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        sessionAttributes.Confirmation = "serviceNow";
        sessionAttributes.shortDescriptionTriggred = "false";
        sessionAttributes.shortDescriptionReceived = "false"
        Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
//this will invoke further assistance
exports.modelFurtherAssistance = async function (intentRequest, callback) {
    var menuItems, menuItemsEn, ButtonData, translatedButtonText
    var btnYesNo = [];
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var message = "Thank you for your feedback. Do you need any other assistance?";
    const type = "Menu";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    try {
        // Fetches the Menu Options from the table
        const results = await dbCall.callMenuTable('Menu', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('Menu', 'en');
        if (results) {
            menuItems = results.Item.SubModule.L
            menuItemsEn = resultsEn.Item.SubModule.L
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.SubModuleName.S
                    var menuEn = menuItemsEn[i].M.SubModuleName.S
                    btnYesNo.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        }
        else {
            menuItems = resultsEn.Item.SubModule.L;
            console.log("sub menu items in else loop", menuItems);
            //sonal
            var menuArr = [...new Set(menuItems.map(x => x.M.SubModuleName.S))]; //array of menu
            console.log("sub menu after filter ", menuArr)
            var menuStr = menuArr.toString(); //menu array to string
            menuStr = menuStr.toLowerCase().replace(/,/g, "/");
            var translatedMenu;
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split("/");
            }
            for (var j = 0; j < menuArr.length; j++) {
                btnYesNo.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }

        }
        ButtonData = Templates.getButtons(btnYesNo);
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        sessionAttributes.Confirmation = "FurtherAssistance";
        Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
// Final Message to be displayed
exports.modelEndGreetings = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var message = "Thank you, Have a nice day";
    try {
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
        }
        const type = "Menu";
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
exports.shortDescription = async function (intentRequest, callback, count) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    try {
        // If the user enters gibberish in short description
        if (count > 1) {
            message = "Please enter a valid short description of your issue";
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        else {
            // Fetches the Short Description message from the table
            const results = await dbCall.callMenuTable('Short Description', sessionAttributes.SourceCode);
            const resultsEn = await dbCall.callMenuTable('Short Description', 'en');
            if (results) {
                message = results.Item.Message.S;
            }
            else {
                message = resultsEn.Item.Message.S
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        sessionAttributes.serviceNowTriggred = 'true';
        sessionAttributes.OutputType = "shortDescription";
        return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
exports.incidentDescription = async function (intentRequest, callback, count) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    try {
        // If the user enters gibberish in description
        if (count > 1) {
            message = "Please enter a valid description of your issue";
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        else {
            // Fetches the incident description message from the table
            const results = await dbCall.callMenuTable('Incident Description', sessionAttributes.SourceCode);
            const resultsEn = await dbCall.callMenuTable('Incident Description', 'en');
            if (results) {
                message = results.Item.Message.S;
            }
            else {
                message = resultsEn.Item.Message.S
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        console.log("in incident description of common response")
        sessionAttributes.serviceNowStage = 'description';
        sessionAttributes.OutputType = "incidentDescription";
        return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
//Method to display the urgency menu to the user
exports.serviceNowUrgency = async function (intentRequest, callback, count) {
    var ButtonData, translatedMenu, message, translatedButtonText;
    var otherLangMenu = [], menuItems = [], menuItemsEn = [],btn = [];
    const type = "Menu";
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    try {
        // Fetch the Urgency menu options from the table
        const results = await dbCall.callMenuTable('Urgency', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('Urgency', 'en');
        if (results) {
            menuItems = results.Item.Items.L;
            menuItemsEn = resultsEn.Item.Items.L;
            message = results.Item.Message.S
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.name.S
                    var menuEn = menuItemsEn[i].M.name.S
                    btn.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        }
        else {
            menuItems = resultsEn.Item.Items.L;
            message = results.Item.Message.S
            menuItems.forEach(e => {
                otherLangMenu.push(e.M.name.S)
            })
            var menuStr = otherLangMenu.toString(); //menu array to string
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split(",");
            }
            for (var j = 0; j < menuItems.length; j++) {
                btn.push({
                    text: translatedMenu[j],
                    Value: menuItems[j].M.name.S,
                });
            }

        }
        if (count > 1) {
            message = "Please select a valid 'Urgency' option from this menu"
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        ButtonData = Templates.getButtons(btn);
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        if(sessionAttributes.serviceNowFlow === "guidedResolution")
        {
            console.log("service not stage will be state")
            sessionAttributes.serviceNowStage = 'urgency'
        }
        return Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch (error) {
        errorMessages.generalError(intentRequest, callback)
    }
};
// Fetches the category menu options from the table
exports.serviceNowCategory = async function (intentRequest, callback, count) {
    var ButtonData, translatedMenu, message, translatedButtonText, menuItems, menuItemsEn;
    var btn = [], btn1 = [], otherLangMenu = [];
    const type = "Menu";
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    try {
        //Fetch the Category Menu Options from the table
        const results = await dbCall.callMenuTable('Category', sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable('Category', 'en');
        if (results) {
            menuItems = results.Item.Items.L;
            menuItemsEn = resultsEn.Item.Items.L;
            message = results.Item.Message.S;
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.name.S
                    var menuEn = menuItemsEn[i].M.name.S
                    if (i < 5) {
                        btn.push({
                            text: menu,
                            Value: menuEn,
                        });
                    }
                    else {
                        btn1.push({
                            text: menu,
                            Value: menuEn,
                        });
                    }
                }
            }
        }
        else {
            menuItems = resultsEn.Item.Items.L;
            message = resultsEn.Item.Message.S
            menuItems.forEach(e => {
                otherLangMenu.push(e.M.name.S)
            })
            var menuStr = otherLangMenu.toString(); //menu array to string
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
                translatedMenu = translatedButtonText.split(",");
            }
            for (var j = 0; j < menuItems.length; j++) {
                if (j < 5) {
                    btn.push({
                        text: translatedMenu[j],
                        Value: menuItems[j].M.name.S,
                    });
                }
                else {
                    btn1.push({
                        text: translatedMenu[j],
                        Value: menuItems[j].M.name.S,
                    });
                }
            }

        }
        if (count > 1) {
            message = "Please select a valid 'Category' from the below options"
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
        }
        const AppState = intentName;
        Session.setCurrentIntent(sessionAttributes, intentName);
        Session.setCurrentOutputType(sessionAttributes, type);
        Session.setCurrentAppState(sessionAttributes, AppState);
        ButtonData = Templates.getButtons(btn);
        if (btn1.length > 0) {
            var ButtonData1 = Templates.getButtons(btn1);
            return Templates.getResponseCardTemplateOne(sessionAttributes, message, ButtonData, ButtonData1, callback);
        } else {
            return Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
        }
    }
    catch (e) {
        errorMessages.generalError(intentRequest, callback)
    }
};
