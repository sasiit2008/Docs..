'use strict';
// Import Functional Modules
const commonFunction = require('./commonFunctions')
const Templates = require("./helperFunctions");
const Session = require("../LatisModules/session");

// Function to display when there is no answer present in the table
exports.modelFaqNotAcessible = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var message = "Sorry, I don't have an answer for this question.Please ask something else or type 'Help'";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    const type = "Menu";
    const AppState = intentName;
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);
    sessionAttributes.OutputType = "Greet";
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};
// When the bot is not able to understand user's query
exports.modelErrorHandling = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    const type = "Menu";
    var message = "Sorry, I don't have answer for this. Please type 'Help'";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    console.log("Error Handling was hit");
    sessionAttributes.OutputType = "Greet";
    Session.setCurrentOutputType(sessionAttributes, type);
    return Templates.getCloseResponseTemplate(sessionAttributes, message, callback);
};
//This will be called when the user is not authorized to use the chatbot
exports.modelNotAuthorised = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    const type = "Menu";
    message = "You are not authorized to use this chatbot";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    Session.setCurrentOutputType(sessionAttributes, type);
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};
// This will be triggered where the is some technical issue at the backend
exports.generalError = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    sessionAttributes.previousIntent=null;
    var message;
    const type = "Menu";
    message = "I am facing some technical issue at the backend, please try again later";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    Session.setCurrentOutputType(sessionAttributes, type);
    sessionAttributes.serviceNowTriggred = 'false'
    sessionAttributes.serviceNowStage = null
    sessionAttributes.previousIntent = null
    sessionAttributes.intentStage=null;
    sessionAttributes.desc=null;
    sessionAttributes.incidentDescription=null;
    sessionAttributes.serviceNowCategory=null;
    sessionAttributes.serviceNowFlow=null;
    sessionAttributes.cafMenuTriggered = null;
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};
// This will be executed when the service now flow has exhausted
exports.exhaustAttempts = async function (intentRequest, callback) {
    console.log("exhaust attempts is hit");
    console.log(intentRequest);
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    const type = "Menu";
    message = "I am Terminating the flow because of your invalid inputs. Please type 'Help' if you need any other help";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    console.log("the message we got is in translation", message);
    Session.setCurrentOutputType(sessionAttributes, type);
    sessionAttributes.serviceNowTriggred = 'false'
    sessionAttributes.serviceNowStage = null
    sessionAttributes.previousIntent = null
    sessionAttributes.intentStage=null;
    sessionAttributes.desc=null;
    sessionAttributes.incidentDescription=null;
    sessionAttributes.serviceNowCategory=null;
    sessionAttributes.serviceNowFlow=null;
    sessionAttributes.cafMenuTriggered = null;
    console.log("the error template is returned");
    console.log(message);
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};
exports.dataNotAuthorised = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    const type = "Menu";
    message = "You are not authorized to view this data. If you need any assistance, please type 'Help'";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    Session.setCurrentOutputType(sessionAttributes, type);
    sessionAttributes.serviceNowTriggred = 'false'
    sessionAttributes.serviceNowStage = null
    sessionAttributes.previousIntent = null
    sessionAttributes.intentStage=null;
    sessionAttributes.desc=null;
    sessionAttributes.incidentDescription=null;
    sessionAttributes.serviceNowCategory=null;
    sessionAttributes.serviceNowFlow=null;
    sessionAttributes.cafMenuTriggered = null;
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};

exports.userOperation = async function (intentRequest, callback) {
    console.log("user operation restrict triggred");
    var sessionAttributes = intentRequest.sessionAttributes;
    var message;
    const type = "Menu";
    message = " You are not authorized to perform this operation";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    Session.setCurrentOutputType(sessionAttributes, type);
    return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
};