//Configuring AWS Parameters
const AWS = require('aws-sdk');
AWS.config.update({ region: "eu-west-1" });
const translate = new AWS.Translate();
const dynamoDB = new AWS.DynamoDB();

// Variable Declaration
var userIdFromJde;
var finalMessage,terminologyName;
exports.handler = async (event, context, callback) => {
 
  try {
    // Pass the User Id coming from the chat-widget
    // User ID will be passed in the query to get the language associated
    userIdFromJde = event.userId
    var ObtainedRes
    if (userIdFromJde) {
      var params = {
        Key: {
          "UserId": { "S": userIdFromJde },
        },
        TableName: "vwt_corp_latis_language"
      };
      const results = await dynamoDB.getItem(params).promise()
      console.log(JSON.stringify(results))
      if (results.Item) {
        if (results.Item.Lang) {
          ObtainedRes = results.Item.Lang.S.trim()
        }
      }
    }

    // Define Custom Terminology based on the language fetched
    switch (ObtainedRes) {
      case 'fr':
        terminologyName = "frenchTerminology"
        break;
      case 'es':
        terminologyName = "spanishTerminology"
        break;
      case 'it':
        terminologyName = "italianTerminology"
        break;
      case 'pt':
        terminologyName = "portugueseTerminology"
        break;
      case 'de':
        terminologyName = "germanTerminology"
        break;
      case 'zh':
        terminologyName = "chineseTerminology"
        break;
      default:
        terminologyName = "EnglishTerminology"
    }
    // Translate based on the below parameters
    try {
      const translateParams = {
        TerminologyNames: [terminologyName],
        SourceLanguageCode: ObtainedRes ? ObtainedRes : "en",
        TargetLanguageCode: event.sourceLang ? event.sourceLang : "en", /* required */
        Text: event.userMessage, /* required */
      };
      const data = await translate.translateText(translateParams).promise();

      // Service Now Description and Short Description Logic
      switch (event.OutputType) {
        case "shortDescription": finalMessage = event.userMessage;
          break;
        case "incidentDescription":
          if(ObtainedRes==="en")
          {
            finalMessage = event.userMessage;
            console.log("english", finalMessage);
          }
          else
          {
            finalMessage = event.userMessage + "+" + data.TranslatedText
          }
          break;
        default: finalMessage = data.TranslatedText
          break;

      }
      // Send the Response back to the chat-widget
      callback(null, {
        "TranslatedText": finalMessage,
        "SourceLanguageCode": ObtainedRes ? ObtainedRes : "en",

      });

    } catch (err) {
      console.log(err, err.stack);
    }
  } catch (err) {
    console.log(err);
    return err;
  }

};



